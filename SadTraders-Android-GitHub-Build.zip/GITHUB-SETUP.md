# Sad Traders GitHub setup

Target repository:
`insta0123saad-collab/saad-traders-shop`

1. Upload the Android project files to the repository (or a dedicated Android app repository).
2. Keep `app/google-services.json` in the repository only if you accept the normal Firebase client config exposure model. Do not upload any Firebase Admin/service-account JSON.
3. Go to GitHub -> Actions -> Build Sad Traders Android APK -> Run workflow.
4. After the workflow finishes, open the run and download the `Sad-Traders-debug-apk` artifact.

## Important security action
The Firebase Admin service-account JSON uploaded during setup contains a private key. Revoke/delete that key in Firebase/Google Cloud and create a fresh key if the old key has been exposed beyond the intended secure secret store.
