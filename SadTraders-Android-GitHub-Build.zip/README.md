# Sad Traders Android App

This Android app wraps the existing Sad Traders customer shop:
https://insta0123saad-collab.github.io/saad-traders-shop/

## Included
- Sad Traders branded Android app shell
- WebView customer shop
- Android back button support
- File/image chooser support
- External intents for tel:, WhatsApp and payment links
- Firebase Cloud Messaging (FCM)
- Subscription to the `all_customers` topic
- Android 13+ notification permission
- Notification channel: `sad_traders_general`

## Before building
1. Create/register an Android app in your Firebase project.
2. Use package name: `com.saadtraders.shop`
3. Download Firebase's `google-services.json`.
4. Put it at `app/google-services.json`.
5. Open the project in Android Studio and sync Gradle.
6. Build APK.

The current Firebase Android BoM used here is 34.17.0 and Google Services plugin is 4.5.0.

## Push notifications
The Supabase Edge Function already created for this project is:
`send-customer-notification`

It sends a notification to the Firebase topic:
`all_customers`

The Edge Function expects the secret:
`FCM_SERVICE_ACCOUNT_JSON`

Do NOT put the Firebase service-account JSON inside this Android app or website. It belongs only in the Supabase Edge Function secrets.

## Admin panel
Your admin website should call the Edge Function with the signed-in admin user's Supabase session. Example:

const { data, error } = await supabase.functions.invoke(
  'send-customer-notification',
  { body: { title: 'New Offer 🎉', body: 'Get ₹100 off today!' } }
);

Only a Supabase user whose `profiles.role` is `admin` can send notifications.

## Supabase project
Project ref: bzyonildigzsytuprfrh
Region: ap-southeast-1
