# Sad Traders currently does not require custom ProGuard rules.
